# Sistem Informasi Apotek - UI Modern

Aplikasi HTML, CSS, dan JavaScript berbasis browser.

## Akun Demo
- Apoteker: `apoteker` / `apoteker123`
- Kasir: `kasir` / `kasir123`
- Admin: `admin` / `admin123`

## Cara Menjalankan
Buka file `index.html` di browser.

## Fitur
- Login berdasarkan role
- Cek ketersediaan obat
- Pemberian obat resep
- Notifikasi stok menipis
- Transaksi penjualan
- Cetak struk
- Kelola data obat
- Monitor stok obat
- Laporan penjualan otomatis
