# Database Sistem Informasi Apotek

Database ini dibuat sesuai rancangan use case, activity diagram, dan sequence diagram Sistem Informasi Apotek.

## Isi database

Nama database: `sistem_informasi_apotek`

Tabel utama:

1. `users` - data akun login Apoteker, Kasir, dan Admin.
2. `obat` - data master obat.
3. `resep` - data resep pasien.
4. `resep_detail` - detail obat pada resep.
5. `transaksi` - data transaksi penjualan.
6. `transaksi_detail` - detail obat yang dibeli.
7. `struk` - riwayat cetak struk.
8. `notifikasi_stok` - notifikasi stok menipis/habis.
9. `stok_log` - riwayat perubahan stok.

View laporan:

1. `view_stok_menipis`
2. `view_laporan_penjualan_harian`
3. `view_obat_terjual`

## Akun login demo

| Role | Username | Password |
|---|---|---|
| Apoteker | `apoteker` | `apoteker123` |
| Kasir | `kasir` | `kasir123` |
| Admin | `admin` | `admin123` |

## Cara import di XAMPP/phpMyAdmin

1. Jalankan Apache dan MySQL dari XAMPP.
2. Buka `http://localhost/phpmyadmin`.
3. Klik menu **Import**.
4. Pilih file `database/sistem_informasi_apotek.sql`.
5. Klik **Go / Kirim**.
6. Database akan otomatis dibuat dengan nama `sistem_informasi_apotek`.

## Catatan

Password pada data demo masih disimpan dalam teks biasa agar mudah digunakan untuk tugas dan pengujian. Untuk aplikasi produksi, password harus disimpan menggunakan hash seperti `password_hash()` di PHP.

Aplikasi HTML sebelumnya masih berjalan menggunakan `localStorage`. Agar benar-benar terhubung ke MySQL, gunakan file contoh backend PHP pada folder `backend_php` sebagai dasar integrasi.
