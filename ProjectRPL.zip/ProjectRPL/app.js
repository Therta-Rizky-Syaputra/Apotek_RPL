const STORAGE_KEY = "sisfo_apotek_data_v1";
const SESSION_KEY = "sisfo_apotek_session_v1";

const accounts = [
  { username: "apoteker", password: "apoteker123", role: "Apoteker", name: "Apoteker" },
  { username: "kasir", password: "kasir123", role: "Kasir", name: "Kasir" },
  { username: "admin", password: "admin123", role: "Admin", name: "Admin" }
];

const defaultData = {
  medicines: [
    { id: 1, code: "OBT001", name: "Paracetamol 500 mg", category: "Analgesik", price: 7000, stock: 80, minStock: 15, expiry: "2027-02-10" },
    { id: 2, code: "OBT002", name: "Amoxicillin 500 mg", category: "Antibiotik", price: 12000, stock: 12, minStock: 20, expiry: "2026-11-22" },
    { id: 3, code: "OBT003", name: "Cetirizine 10 mg", category: "Antihistamin", price: 8500, stock: 31, minStock: 10, expiry: "2027-06-18" },
    { id: 4, code: "OBT004", name: "Vitamin C 500 mg", category: "Vitamin", price: 15000, stock: 6, minStock: 12, expiry: "2026-09-15" },
    { id: 5, code: "OBT005", name: "Antasida DOEN", category: "Pencernaan", price: 9000, stock: 45, minStock: 10, expiry: "2028-01-09" },
    { id: 6, code: "OBT006", name: "Oralit Sachet", category: "Elektrolit", price: 3000, stock: 0, minStock: 20, expiry: "2027-04-01" }
  ],
  transactions: [],
  prescriptions: [],
  receiptPrints: []
};

const menus = {
  Apoteker: [
    ["dashboard", "Dashboard"],
    ["cekObat", "Cek Ketersediaan Obat"],
    ["resep", "Pemberian Obat Resep"],
    ["notifikasi", "Notifikasi Stok Menipis"]
  ],
  Kasir: [
    ["dashboard", "Dashboard"],
    ["transaksi", "Proses Transaksi Penjualan"],
    ["cetakStruk", "Cetak Struk"]
  ],
  Admin: [
    ["dashboard", "Dashboard"],
    ["kelolaObat", "Kelola Data Obat"],
    ["monitorStok", "Monitor Stok Obat"],
    ["laporan", "Laporan Penjualan Otomatis"]
  ]
};

const sections = {
  dashboard: "dashboardSection",
  cekObat: "cekObatSection",
  resep: "resepSection",
  notifikasi: "notifikasiSection",
  transaksi: "transaksiSection",
  cetakStruk: "cetakStrukSection",
  kelolaObat: "kelolaObatSection",
  monitorStok: "monitorStokSection",
  laporan: "laporanSection"
};

let currentUser = null;
let cart = [];
let prescriptionItems = [];
let editingMedicineId = null;

const rupiah = value => new Intl.NumberFormat("id-ID", { style: "currency", currency: "IDR", maximumFractionDigits: 0 }).format(value || 0);
const today = () => new Date().toISOString().slice(0, 10);
const byId = id => document.getElementById(id);

function loadData() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultData));
    return structuredClone(defaultData);
  }
  try {
    const parsed = JSON.parse(raw);
    return {
      medicines: parsed.medicines || [],
      transactions: parsed.transactions || [],
      prescriptions: parsed.prescriptions || [],
      receiptPrints: parsed.receiptPrints || []
    };
  } catch {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultData));
    return structuredClone(defaultData);
  }
}

function saveData(data) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function showToast(message, type = "success") {
  const toast = byId("toast");
  toast.textContent = message;
  toast.className = `toast ${type}`;
  setTimeout(() => toast.classList.add("hidden"), 2600);
}

function statusBadge(stock, minStock) {
  if (stock <= 0) return `<span class="badge danger">Habis</span>`;
  if (stock <= minStock) return `<span class="badge warn">Menipis</span>`;
  return `<span class="badge ok">Tersedia</span>`;
}

function medicineOptions(selected = "") {
  const data = loadData();
  return data.medicines.map(m => `<option value="${m.code}" ${m.code === selected ? "selected" : ""}>${m.code} - ${m.name} (Stok: ${m.stock})</option>`).join("");
}

function login(username, password) {
  const user = accounts.find(a => a.username === username && a.password === password);
  if (!user) return false;
  currentUser = user;
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(user));
  return true;
}

function logout() {
  currentUser = null;
  sessionStorage.removeItem(SESSION_KEY);
  byId("appPage").classList.add("hidden");
  byId("loginPage").classList.remove("hidden");
  byId("loginForm").reset();
}

function startApp() {
  byId("loginPage").classList.add("hidden");
  byId("appPage").classList.remove("hidden");
  byId("userRoleText").textContent = `${currentUser.name} • ${currentUser.role}`;
  renderMenu();
  navigate("dashboard");
}

function renderMenu() {
  byId("menuList").innerHTML = menus[currentUser.role].map(([key, label]) => `
    <button class="menu-item" data-page="${key}">${label}</button>
  `).join("");
  document.querySelectorAll(".menu-item").forEach(btn => btn.addEventListener("click", () => navigate(btn.dataset.page)));
}

function navigate(page) {
  Object.values(sections).forEach(id => byId(id).classList.add("hidden"));
  byId(sections[page]).classList.remove("hidden");
  document.querySelectorAll(".menu-item").forEach(btn => btn.classList.toggle("active", btn.dataset.page === page));
  const label = menus[currentUser.role].find(([key]) => key === page)?.[1] || "Dashboard";
  byId("pageTitle").textContent = label;

  const renderers = {
    dashboard: renderDashboard,
    cekObat: renderCekObat,
    resep: renderResep,
    notifikasi: renderNotifikasi,
    transaksi: renderTransaksi,
    cetakStruk: renderCetakStruk,
    kelolaObat: renderKelolaObat,
    monitorStok: renderMonitorStok,
    laporan: renderLaporan
  };
  renderers[page]?.();
}

function renderDashboard() {
  const data = loadData();
  const totalObat = data.medicines.length;
  const stokMenipis = data.medicines.filter(m => m.stock <= m.minStock).length;
  const transaksiHariIni = data.transactions.filter(t => t.date.slice(0, 10) === today()).length;
  const resepHariIni = data.prescriptions.filter(p => p.date.slice(0, 10) === today()).length;

  byId("dashboardSection").innerHTML = `
    <div class="grid cols-3">
      <div class="card stat-card"><span>Total Obat</span><strong>${totalObat}</strong></div>
      <div class="card stat-card"><span>Stok Menipis/Habis</span><strong>${stokMenipis}</strong></div>
      <div class="card stat-card"><span>Transaksi Hari Ini</span><strong>${transaksiHariIni}</strong></div>
    </div>
    <div class="grid cols-2" style="margin-top:18px">
      <div class="card">
        <h2>Role Aktif</h2>
        <p>Anda masuk sebagai <b>${currentUser.role}</b>. Menu yang tampil mengikuti hak akses role pada use case diagram.</p>
      </div>
      <div class="card">
        <h2>Ringkasan Resep</h2>
        <p>Resep diproses hari ini: <b>${resepHariIni}</b></p>
      </div>
    </div>
  `;
}

function renderMedicineTable(rows, withActions = false) {
  if (!rows.length) return `<div class="empty">Data obat tidak ditemukan.</div>`;
  return `
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Kode</th><th>Nama Obat</th><th>Kategori</th><th>Harga</th><th>Stok</th><th>Batas Minimum</th><th>Kadaluarsa</th><th>Status</th>${withActions ? "<th>Aksi</th>" : ""}
          </tr>
        </thead>
        <tbody>
          ${rows.map(m => `
            <tr>
              <td>${m.code}</td>
              <td><b>${m.name}</b></td>
              <td>${m.category}</td>
              <td>${rupiah(m.price)}</td>
              <td>${m.stock}</td>
              <td>${m.minStock}</td>
              <td>${m.expiry}</td>
              <td>${statusBadge(m.stock, m.minStock)}</td>
              ${withActions ? `<td><div class="actions"><button class="btn ghost sm" onclick="editMedicine(${m.id})">Edit</button><button class="btn danger sm" onclick="deleteMedicine(${m.id})">Hapus</button></div></td>` : ""}
            </tr>
          `).join("")}
        </tbody>
      </table>
    </div>
  `;
}

function renderCekObat() {
  const data = loadData();
  byId("cekObatSection").innerHTML = `
    <div class="card">
      <h2>Cek Ketersediaan Obat</h2>
      <div class="form-grid">
        <label class="wide">Cari nama/kode obat
          <input id="searchMedicine" type="text" placeholder="Masukkan nama atau kode obat" />
        </label>
      </div>
      <div style="margin-top:14px" class="actions">
        <button id="searchMedicineBtn" class="btn primary">Cari Obat</button>
        <button id="showAllMedicineBtn" class="btn ghost">Tampilkan Semua</button>
      </div>
    </div>
    <div id="cekObatResult" style="margin-top:18px">${renderMedicineTable(data.medicines)}</div>
  `;
  byId("searchMedicineBtn").onclick = () => {
    const q = byId("searchMedicine").value.trim().toLowerCase();
    const rows = data.medicines.filter(m => m.code.toLowerCase().includes(q) || m.name.toLowerCase().includes(q));
    byId("cekObatResult").innerHTML = renderMedicineTable(rows);
  };
  byId("showAllMedicineBtn").onclick = () => renderCekObat();
}

function renderResep() {
  byId("resepSection").innerHTML = `
    <div class="grid cols-2">
      <div class="card">
        <h2>Pemberian Obat Resep</h2>
        <div class="form-grid">
          <label>Nama Pasien<input id="patientName" type="text" placeholder="Nama pasien" /></label>
          <label>Dokter<input id="doctorName" type="text" placeholder="Nama dokter" /></label>
          <label class="wide">Catatan Resep<textarea id="recipeNote" placeholder="Aturan pakai/catatan resep"></textarea></label>
        </div>
        <hr style="border:0;border-top:1px solid var(--line);margin:18px 0">
        <div class="item-row">
          <label>Obat<select id="recipeMedicine">${medicineOptions()}</select></label>
          <label>Jumlah<input id="recipeQty" type="number" min="1" value="1" /></label>
          <button id="addRecipeItemBtn" class="btn primary">Tambah</button>
        </div>
        <div class="actions" style="margin-top:14px">
          <button id="processRecipeBtn" class="btn primary">Proses Resep</button>
          <button id="clearRecipeBtn" class="btn ghost">Bersihkan</button>
        </div>
      </div>
      <div class="card">
        <h2>Daftar Obat Resep</h2>
        <div id="recipeItems"></div>
      </div>
    </div>
  `;
  byId("addRecipeItemBtn").onclick = addRecipeItem;
  byId("processRecipeBtn").onclick = processRecipe;
  byId("clearRecipeBtn").onclick = () => { prescriptionItems = []; renderResep(); };
  updateRecipeItems();
}

function addRecipeItem() {
  const data = loadData();
  const code = byId("recipeMedicine").value;
  const qty = Number(byId("recipeQty").value);
  const medicine = data.medicines.find(m => m.code === code);
  if (!medicine || qty <= 0) return showToast("Data obat atau jumlah tidak valid.", "error");
  const existing = prescriptionItems.find(i => i.code === code);
  if (existing) existing.qty += qty;
  else prescriptionItems.push({ code, name: medicine.name, qty });
  updateRecipeItems();
}

function updateRecipeItems() {
  const el = byId("recipeItems");
  if (!el) return;
  if (!prescriptionItems.length) {
    el.innerHTML = `<div class="empty">Belum ada obat dalam resep.</div>`;
    return;
  }
  el.innerHTML = `
    <div class="table-wrap">
      <table style="min-width:420px"><thead><tr><th>Obat</th><th>Jumlah</th><th>Aksi</th></tr></thead><tbody>
      ${prescriptionItems.map((i, idx) => `<tr><td>${i.name}</td><td>${i.qty}</td><td><button class="btn danger sm" onclick="removeRecipeItem(${idx})">Hapus</button></td></tr>`).join("")}
      </tbody></table>
    </div>
  `;
}

function removeRecipeItem(index) {
  prescriptionItems.splice(index, 1);
  updateRecipeItems();
}

function processRecipe() {
  const patientName = byId("patientName").value.trim();
  const doctorName = byId("doctorName").value.trim();
  const note = byId("recipeNote").value.trim();
  if (!patientName || !doctorName || prescriptionItems.length === 0) return showToast("Lengkapi data pasien, dokter, dan obat resep.", "error");
  const data = loadData();
  for (const item of prescriptionItems) {
    const med = data.medicines.find(m => m.code === item.code);
    if (!med || med.stock < item.qty) return showToast(`Stok ${item.name} tidak cukup.`, "error");
  }
  prescriptionItems.forEach(item => {
    const med = data.medicines.find(m => m.code === item.code);
    med.stock -= item.qty;
  });
  data.prescriptions.push({
    id: `RSP-${Date.now()}`,
    patientName,
    doctorName,
    note,
    items: prescriptionItems,
    apoteker: currentUser.name,
    date: new Date().toISOString(),
    status: "Selesai"
  });
  saveData(data);
  prescriptionItems = [];
  showToast("Resep berhasil diproses dan stok diperbarui.");
  renderResep();
}

function renderNotifikasi() {
  const data = loadData();
  const low = data.medicines.filter(m => m.stock <= m.minStock);
  byId("notifikasiSection").innerHTML = `
    <div class="card">
      <h2>Notifikasi Stok Menipis</h2>
      <p>Daftar obat yang stoknya sudah mencapai atau berada di bawah batas minimum.</p>
      ${renderMedicineTable(low)}
    </div>
  `;
}

function renderTransaksi() {
  byId("transaksiSection").innerHTML = `
    <div class="grid cols-2">
      <div class="card">
        <h2>Proses Transaksi Penjualan</h2>
        <div class="item-row">
          <label>Obat<select id="cartMedicine">${medicineOptions()}</select></label>
          <label>Jumlah<input id="cartQty" type="number" min="1" value="1" /></label>
          <button id="addCartBtn" class="btn primary">Tambah</button>
        </div>
        <div style="margin-top:16px" class="form-grid">
          <label>Uang Bayar<input id="paymentAmount" type="number" min="0" placeholder="Masukkan nominal pembayaran" /></label>
        </div>
        <div class="actions" style="margin-top:14px">
          <button id="finishTransactionBtn" class="btn primary">Selesaikan Transaksi</button>
          <button id="clearCartBtn" class="btn ghost">Bersihkan Keranjang</button>
        </div>
      </div>
      <div class="card">
        <h2>Keranjang</h2>
        <div id="cartItems"></div>
      </div>
    </div>
  `;
  byId("addCartBtn").onclick = addCartItem;
  byId("finishTransactionBtn").onclick = finishTransaction;
  byId("clearCartBtn").onclick = () => { cart = []; updateCart(); };
  updateCart();
}

function addCartItem() {
  const data = loadData();
  const code = byId("cartMedicine").value;
  const qty = Number(byId("cartQty").value);
  const med = data.medicines.find(m => m.code === code);
  if (!med || qty <= 0) return showToast("Data obat atau jumlah tidak valid.", "error");
  const existingQty = cart.find(i => i.code === code)?.qty || 0;
  if (med.stock < existingQty + qty) return showToast("Stok obat tidak cukup.", "error");
  const existing = cart.find(i => i.code === code);
  if (existing) existing.qty += qty;
  else cart.push({ code, name: med.name, price: med.price, qty });
  updateCart();
}

function cartTotal() {
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);
  const tax = Math.round(subtotal * 0.0);
  return { subtotal, tax, total: subtotal + tax };
}

function updateCart() {
  const el = byId("cartItems");
  if (!el) return;
  if (!cart.length) {
    el.innerHTML = `<div class="empty">Keranjang masih kosong.</div>`;
    return;
  }
  const total = cartTotal();
  el.innerHTML = `
    <div class="table-wrap">
      <table style="min-width:520px"><thead><tr><th>Obat</th><th>Harga</th><th>Qty</th><th>Subtotal</th><th>Aksi</th></tr></thead><tbody>
      ${cart.map((i, idx) => `<tr><td>${i.name}</td><td>${rupiah(i.price)}</td><td>${i.qty}</td><td>${rupiah(i.price * i.qty)}</td><td><button class="btn danger sm" onclick="removeCartItem(${idx})">Hapus</button></td></tr>`).join("")}
      </tbody></table>
    </div>
    <div class="summary-box" style="margin-top:14px">
      <div class="summary-line"><span>Subtotal</span><b>${rupiah(total.subtotal)}</b></div>
      <div class="summary-line"><span>Pajak</span><b>${rupiah(total.tax)}</b></div>
      <div class="summary-line total"><span>Total</span><b>${rupiah(total.total)}</b></div>
    </div>
  `;
}

function removeCartItem(index) {
  cart.splice(index, 1);
  updateCart();
}

function finishTransaction() {
  if (!cart.length) return showToast("Keranjang masih kosong.", "error");
  const payment = Number(byId("paymentAmount").value);
  const total = cartTotal();
  if (payment < total.total) return showToast("Pembayaran kurang.", "error");
  const data = loadData();
  for (const item of cart) {
    const med = data.medicines.find(m => m.code === item.code);
    if (!med || med.stock < item.qty) return showToast(`Stok ${item.name} tidak cukup.`, "error");
  }
  cart.forEach(item => {
    const med = data.medicines.find(m => m.code === item.code);
    med.stock -= item.qty;
  });
  const transaction = {
    id: `TRX-${Date.now()}`,
    date: new Date().toISOString(),
    kasir: currentUser.name,
    items: cart,
    subtotal: total.subtotal,
    tax: total.tax,
    total: total.total,
    payment,
    change: payment - total.total
  };
  data.transactions.push(transaction);
  saveData(data);
  cart = [];
  showToast("Transaksi berhasil disimpan dan stok diperbarui.");
  renderTransaksi();
  showReceipt(transaction);
}

function renderCetakStruk() {
  const data = loadData();
  const rows = [...data.transactions].reverse();
  byId("cetakStrukSection").innerHTML = `
    <div class="card">
      <h2>Cetak Struk</h2>
      ${rows.length ? `
        <div class="table-wrap"><table>
          <thead><tr><th>ID Transaksi</th><th>Tanggal</th><th>Kasir</th><th>Total</th><th>Bayar</th><th>Kembalian</th><th>Aksi</th></tr></thead>
          <tbody>${rows.map(t => `<tr><td>${t.id}</td><td>${new Date(t.date).toLocaleString("id-ID")}</td><td>${t.kasir}</td><td>${rupiah(t.total)}</td><td>${rupiah(t.payment)}</td><td>${rupiah(t.change)}</td><td><button class="btn primary sm" onclick='showReceiptById("${t.id}")'>Cetak</button></td></tr>`).join("")}</tbody>
        </table></div>` : `<div class="empty">Belum ada transaksi.</div>`}
    </div>
  `;
}

function receiptHTML(t) {
  return `
    <div class="center"><h3>APOTEK SEHAT</h3><p>Sistem Informasi Apotek</p></div><hr>
    <div>ID: ${t.id}</div>
    <div>Tanggal: ${new Date(t.date).toLocaleString("id-ID")}</div>
    <div>Kasir: ${t.kasir}</div><hr>
    ${t.items.map(i => `<div><b>${i.name}</b></div><div class="receipt-row"><span>${i.qty} x ${rupiah(i.price)}</span><span>${rupiah(i.qty * i.price)}</span></div>`).join("")}
    <hr>
    <div class="receipt-row"><span>Subtotal</span><b>${rupiah(t.subtotal)}</b></div>
    <div class="receipt-row"><span>Pajak</span><b>${rupiah(t.tax)}</b></div>
    <div class="receipt-row"><span>Total</span><b>${rupiah(t.total)}</b></div>
    <div class="receipt-row"><span>Bayar</span><b>${rupiah(t.payment)}</b></div>
    <div class="receipt-row"><span>Kembali</span><b>${rupiah(t.change)}</b></div>
    <hr><div class="center">Terima kasih</div>
  `;
}

function showReceiptById(id) {
  const t = loadData().transactions.find(x => x.id === id);
  if (t) showReceipt(t);
}

function showReceipt(transaction) {
  byId("receiptContent").innerHTML = receiptHTML(transaction);
  byId("receiptDialog").showModal();
}

function renderKelolaObat() {
  const data = loadData();
  const editing = data.medicines.find(m => m.id === editingMedicineId);
  byId("kelolaObatSection").innerHTML = `
    <div class="grid cols-2">
      <div class="card">
        <h2>${editing ? "Edit Data Obat" : "Tambah Data Obat"}</h2>
        <form id="medicineForm" class="form-grid">
          <label>Kode<input id="medCode" type="text" value="${editing?.code || ""}" required /></label>
          <label>Nama Obat<input id="medName" type="text" value="${editing?.name || ""}" required /></label>
          <label>Kategori<input id="medCategory" type="text" value="${editing?.category || ""}" required /></label>
          <label>Harga<input id="medPrice" type="number" min="0" value="${editing?.price || ""}" required /></label>
          <label>Stok<input id="medStock" type="number" min="0" value="${editing?.stock ?? ""}" required /></label>
          <label>Batas Minimum<input id="medMinStock" type="number" min="0" value="${editing?.minStock ?? ""}" required /></label>
          <label class="wide">Tanggal Kadaluarsa<input id="medExpiry" type="date" value="${editing?.expiry || today()}" required /></label>
          <div class="actions wide">
            <button type="submit" class="btn primary">${editing ? "Simpan Perubahan" : "Tambah Obat"}</button>
            ${editing ? `<button type="button" id="cancelEditMedicineBtn" class="btn ghost">Batal Edit</button>` : ""}
          </div>
        </form>
      </div>
      <div class="card">
        <h2>Daftar Obat</h2>
        ${renderMedicineTable(data.medicines, true)}
      </div>
    </div>
  `;
  byId("medicineForm").onsubmit = saveMedicineForm;
  const cancel = byId("cancelEditMedicineBtn");
  if (cancel) cancel.onclick = () => { editingMedicineId = null; renderKelolaObat(); };
}

function saveMedicineForm(e) {
  e.preventDefault();
  const data = loadData();
  const item = {
    code: byId("medCode").value.trim().toUpperCase(),
    name: byId("medName").value.trim(),
    category: byId("medCategory").value.trim(),
    price: Number(byId("medPrice").value),
    stock: Number(byId("medStock").value),
    minStock: Number(byId("medMinStock").value),
    expiry: byId("medExpiry").value
  };
  if (!item.code || !item.name || item.price < 0 || item.stock < 0 || item.minStock < 0) return showToast("Data obat tidak valid.", "error");
  const duplicate = data.medicines.find(m => m.code === item.code && m.id !== editingMedicineId);
  if (duplicate) return showToast("Kode obat sudah digunakan.", "error");
  if (editingMedicineId) {
    const med = data.medicines.find(m => m.id === editingMedicineId);
    Object.assign(med, item);
    showToast("Data obat berhasil diperbarui.");
  } else {
    data.medicines.push({ id: Date.now(), ...item });
    showToast("Data obat berhasil ditambahkan.");
  }
  saveData(data);
  editingMedicineId = null;
  renderKelolaObat();
}

function editMedicine(id) {
  editingMedicineId = id;
  renderKelolaObat();
}

function deleteMedicine(id) {
  if (!confirm("Yakin ingin menghapus data obat ini?")) return;
  const data = loadData();
  data.medicines = data.medicines.filter(m => m.id !== id);
  saveData(data);
  showToast("Data obat berhasil dihapus.");
  renderKelolaObat();
}

function renderMonitorStok() {
  const data = loadData();
  const q = byId("monitorSearch")?.value || "";
  const rows = data.medicines.filter(m => m.name.toLowerCase().includes(q.toLowerCase()) || m.code.toLowerCase().includes(q.toLowerCase()));
  byId("monitorStokSection").innerHTML = `
    <div class="card">
      <h2>Monitor Stok Obat</h2>
      <label>Cari obat<input id="monitorSearch" type="text" value="${q}" placeholder="Cari nama/kode obat" /></label>
      <div style="margin-top:16px">${renderMedicineTable(rows)}</div>
    </div>
  `;
  byId("monitorSearch").oninput = () => renderMonitorStok();
}

function renderLaporan() {
  const data = loadData();
  const now = new Date();
  const firstDay = new Date(now.getFullYear(), now.getMonth(), 1).toISOString().slice(0, 10);
  byId("laporanSection").innerHTML = `
    <div class="card">
      <h2>Lihat Laporan Penjualan Otomatis</h2>
      <div class="form-grid">
        <label>Dari tanggal<input id="reportFrom" type="date" value="${firstDay}" /></label>
        <label>Sampai tanggal<input id="reportTo" type="date" value="${today()}" /></label>
      </div>
      <div class="actions" style="margin-top:14px">
        <button id="generateReportBtn" class="btn primary">Tampilkan Laporan</button>
        <button id="exportReportBtn" class="btn ghost">Export Excel/CSV</button>
        <button id="printReportBtn" class="btn ghost">Cetak / Simpan PDF</button>
      </div>
    </div>
    <div id="reportResult" style="margin-top:18px"></div>
  `;
  byId("generateReportBtn").onclick = generateReport;
  byId("exportReportBtn").onclick = exportReportCSV;
  byId("printReportBtn").onclick = () => window.print();
  generateReport();
}

function filteredTransactions() {
  const data = loadData();
  const from = byId("reportFrom").value || "1900-01-01";
  const to = byId("reportTo").value || "2999-12-31";
  return data.transactions.filter(t => {
    const d = t.date.slice(0, 10);
    return d >= from && d <= to;
  });
}

function generateReport() {
  const rows = filteredTransactions();
  const totalSales = rows.reduce((sum, t) => sum + t.total, 0);
  const stockOut = rows.reduce((sum, t) => sum + t.items.reduce((x, i) => x + i.qty, 0), 0);
  byId("reportResult").innerHTML = `
    <div class="grid cols-3">
      <div class="card stat-card"><span>Total Penjualan</span><strong>${rupiah(totalSales)}</strong></div>
      <div class="card stat-card"><span>Jumlah Transaksi</span><strong>${rows.length}</strong></div>
      <div class="card stat-card"><span>Stok Keluar</span><strong>${stockOut}</strong></div>
    </div>
    <div class="card" style="margin-top:18px">
      <h2>Data Transaksi</h2>
      ${rows.length ? `<div class="table-wrap"><table><thead><tr><th>ID</th><th>Tanggal</th><th>Kasir</th><th>Item</th><th>Total</th></tr></thead><tbody>${rows.map(t => `<tr><td>${t.id}</td><td>${new Date(t.date).toLocaleString("id-ID")}</td><td>${t.kasir}</td><td>${t.items.map(i => `${i.name} (${i.qty})`).join(", ")}</td><td>${rupiah(t.total)}</td></tr>`).join("")}</tbody></table></div>` : `<div class="empty">Tidak ada transaksi pada periode ini.</div>`}
    </div>
  `;
}

function exportReportCSV() {
  const rows = filteredTransactions();
  const header = ["ID Transaksi", "Tanggal", "Kasir", "Item", "Total"];
  const csv = [header.join(","), ...rows.map(t => [
    t.id,
    new Date(t.date).toLocaleString("id-ID"),
    t.kasir,
    `"${t.items.map(i => `${i.name} (${i.qty})`).join("; ")}"`,
    t.total
  ].join(","))].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `laporan_penjualan_${today()}.csv`;
  a.click();
  URL.revokeObjectURL(url);
}

function resetData() {
  if (!confirm("Reset semua data demo? Transaksi dan perubahan stok akan dikembalikan ke awal.")) return;
  localStorage.setItem(STORAGE_KEY, JSON.stringify(defaultData));
  cart = [];
  prescriptionItems = [];
  editingMedicineId = null;
  showToast("Data demo berhasil direset.");
  navigate("dashboard");
}

byId("loginForm").addEventListener("submit", e => {
  e.preventDefault();
  const ok = login(byId("username").value.trim(), byId("password").value.trim());
  if (!ok) return showToast("Username atau password salah.", "error");
  startApp();
});
byId("logoutBtn").onclick = logout;
byId("resetDataBtn").onclick = resetData;
byId("closeReceiptBtn").onclick = () => byId("receiptDialog").close();
byId("printReceiptBtn").onclick = () => window.print();

const existingSession = sessionStorage.getItem(SESSION_KEY);
if (existingSession) {
  try {
    currentUser = JSON.parse(existingSession);
    startApp();
  } catch {
    logout();
  }
}
