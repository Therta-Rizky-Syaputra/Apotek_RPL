# Backend PHP Sederhana

Folder ini berisi contoh backend PHP sederhana untuk menghubungkan aplikasi ke database MySQL/MariaDB.

## Cara memakai

1. Import file SQL terlebih dahulu melalui phpMyAdmin.
2. Copy folder `backend_php` ke dalam folder `htdocs`, misalnya:
   `C:\xampp\htdocs\apotek_api`
3. Pastikan konfigurasi pada `koneksi.php` sesuai:
   - host: `localhost`
   - database: `sistem_informasi_apotek`
   - username: `root`
   - password: kosong untuk XAMPP default
4. Coba buka:
   - `http://localhost/apotek_api/obat.php`
   - `http://localhost/apotek_api/notifikasi_stok.php`
   - `http://localhost/apotek_api/laporan.php`

## Endpoint yang tersedia

- `login.php` - login user
- `obat.php` - tampil/tambah/edit/hapus obat
- `notifikasi_stok.php` - melihat stok menipis
- `laporan.php` - melihat transaksi/laporan penjualan

Ini masih backend dasar. Untuk integrasi penuh ke tampilan HTML, JavaScript frontend perlu diarahkan memakai `fetch()` ke endpoint-endpoint ini.
