<?php
header('Content-Type: application/json');
require_once 'koneksi.php';

$mulai = $_GET['mulai'] ?? null;
$sampai = $_GET['sampai'] ?? null;

if ($mulai && $sampai) {
    $stmt = $pdo->prepare('SELECT * FROM transaksi WHERE DATE(tanggal_transaksi) BETWEEN ? AND ? ORDER BY tanggal_transaksi DESC');
    $stmt->execute([$mulai, $sampai]);
} else {
    $stmt = $pdo->query('SELECT * FROM transaksi ORDER BY tanggal_transaksi DESC');
}

$transaksi = $stmt->fetchAll();
$total = array_sum(array_column($transaksi, 'total'));

 echo json_encode([
    'success' => true,
    'jumlah_transaksi' => count($transaksi),
    'total_penjualan' => $total,
    'data' => $transaksi
]);
