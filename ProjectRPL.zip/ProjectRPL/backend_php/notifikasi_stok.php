<?php
header('Content-Type: application/json');
require_once 'koneksi.php';

$stmt = $pdo->query('SELECT * FROM view_stok_menipis ORDER BY stok ASC, nama_obat ASC');
echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
