<?php
header('Content-Type: application/json');
require_once 'koneksi.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $q = $_GET['q'] ?? '';
    if ($q !== '') {
        $stmt = $pdo->prepare('SELECT * FROM obat WHERE kode_obat LIKE ? OR nama_obat LIKE ? ORDER BY nama_obat');
        $stmt->execute(["%$q%", "%$q%"]);
    } else {
        $stmt = $pdo->query('SELECT * FROM obat ORDER BY nama_obat');
    }
    echo json_encode(['success' => true, 'data' => $stmt->fetchAll()]);
    exit;
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $stmt = $pdo->prepare('INSERT INTO obat (kode_obat, nama_obat, kategori, satuan, harga, stok, batas_minimum, tanggal_kadaluarsa) VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $data['kode_obat'],
        $data['nama_obat'],
        $data['kategori'],
        $data['satuan'] ?? 'pcs',
        $data['harga'],
        $data['stok'],
        $data['batas_minimum'],
        $data['tanggal_kadaluarsa'] ?? null
    ]);
    echo json_encode(['success' => true, 'message' => 'Obat berhasil ditambahkan']);
    exit;
}

if ($method === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);
    $stmt = $pdo->prepare('UPDATE obat SET nama_obat=?, kategori=?, satuan=?, harga=?, stok=?, batas_minimum=?, tanggal_kadaluarsa=? WHERE kode_obat=?');
    $stmt->execute([
        $data['nama_obat'],
        $data['kategori'],
        $data['satuan'] ?? 'pcs',
        $data['harga'],
        $data['stok'],
        $data['batas_minimum'],
        $data['tanggal_kadaluarsa'] ?? null,
        $data['kode_obat']
    ]);
    echo json_encode(['success' => true, 'message' => 'Obat berhasil diperbarui']);
    exit;
}

if ($method === 'DELETE') {
    $kode = $_GET['kode_obat'] ?? '';
    $stmt = $pdo->prepare('DELETE FROM obat WHERE kode_obat = ?');
    $stmt->execute([$kode]);
    echo json_encode(['success' => true, 'message' => 'Obat berhasil dihapus']);
    exit;
}

http_response_code(405);
echo json_encode(['success' => false, 'message' => 'Method tidak diizinkan']);
