-- Database Sistem Informasi Apotek
-- Sesuai use case: Login, Apoteker, Kasir, dan Admin
-- Cocok untuk MySQL/MariaDB via XAMPP/phpMyAdmin

DROP DATABASE IF EXISTS sistem_informasi_apotek;
CREATE DATABASE sistem_informasi_apotek
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE sistem_informasi_apotek;

-- ==============================
-- 1. Tabel User / Login
-- ==============================
CREATE TABLE users (
  id_user INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL,
  role ENUM('Apoteker','Kasir','Admin') NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ==============================
-- 2. Tabel Obat
-- ==============================
CREATE TABLE obat (
  id_obat INT AUTO_INCREMENT PRIMARY KEY,
  kode_obat VARCHAR(20) NOT NULL UNIQUE,
  nama_obat VARCHAR(150) NOT NULL,
  kategori VARCHAR(80) NOT NULL,
  satuan VARCHAR(30) DEFAULT 'pcs',
  harga DECIMAL(12,2) NOT NULL DEFAULT 0,
  stok INT NOT NULL DEFAULT 0,
  batas_minimum INT NOT NULL DEFAULT 0,
  tanggal_kadaluarsa DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT chk_stok_nonnegatif CHECK (stok >= 0),
  CONSTRAINT chk_harga_nonnegatif CHECK (harga >= 0)
) ENGINE=InnoDB;

-- ==============================
-- 3. Tabel Resep dan Detail Resep
-- ==============================
CREATE TABLE resep (
  id_resep INT AUTO_INCREMENT PRIMARY KEY,
  nomor_resep VARCHAR(30) NOT NULL UNIQUE,
  nama_pasien VARCHAR(120) NOT NULL,
  tanggal_resep DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  id_apoteker INT NOT NULL,
  status ENUM('Diproses','Selesai','Dibatalkan') DEFAULT 'Selesai',
  catatan TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_resep_apoteker
    FOREIGN KEY (id_apoteker) REFERENCES users(id_user)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE resep_detail (
  id_detail_resep INT AUTO_INCREMENT PRIMARY KEY,
  id_resep INT NOT NULL,
  id_obat INT NOT NULL,
  jumlah INT NOT NULL,
  aturan_pakai VARCHAR(150),
  CONSTRAINT fk_resep_detail_resep
    FOREIGN KEY (id_resep) REFERENCES resep(id_resep)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_resep_detail_obat
    FOREIGN KEY (id_obat) REFERENCES obat(id_obat)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT chk_jumlah_resep_positif CHECK (jumlah > 0)
) ENGINE=InnoDB;

-- ==============================
-- 4. Tabel Transaksi dan Detail Transaksi
-- ==============================
CREATE TABLE transaksi (
  id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
  nomor_transaksi VARCHAR(30) NOT NULL UNIQUE,
  tanggal_transaksi DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  id_kasir INT NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL DEFAULT 0,
  pajak DECIMAL(12,2) NOT NULL DEFAULT 0,
  total DECIMAL(12,2) NOT NULL DEFAULT 0,
  uang_bayar DECIMAL(12,2) NOT NULL DEFAULT 0,
  kembalian DECIMAL(12,2) NOT NULL DEFAULT 0,
  metode_bayar ENUM('Tunai','QRIS','Debit') DEFAULT 'Tunai',
  status ENUM('Berhasil','Dibatalkan') DEFAULT 'Berhasil',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_transaksi_kasir
    FOREIGN KEY (id_kasir) REFERENCES users(id_user)
    ON UPDATE CASCADE ON DELETE RESTRICT
) ENGINE=InnoDB;

CREATE TABLE transaksi_detail (
  id_detail_transaksi INT AUTO_INCREMENT PRIMARY KEY,
  id_transaksi INT NOT NULL,
  id_obat INT NOT NULL,
  jumlah_beli INT NOT NULL,
  harga_satuan DECIMAL(12,2) NOT NULL,
  subtotal DECIMAL(12,2) NOT NULL,
  CONSTRAINT fk_transaksi_detail_transaksi
    FOREIGN KEY (id_transaksi) REFERENCES transaksi(id_transaksi)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_transaksi_detail_obat
    FOREIGN KEY (id_obat) REFERENCES obat(id_obat)
    ON UPDATE CASCADE ON DELETE RESTRICT,
  CONSTRAINT chk_jumlah_beli_positif CHECK (jumlah_beli > 0)
) ENGINE=InnoDB;

-- ==============================
-- 5. Tabel Struk
-- ==============================
CREATE TABLE struk (
  id_struk INT AUTO_INCREMENT PRIMARY KEY,
  id_transaksi INT NOT NULL,
  tanggal_cetak DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status_cetak ENUM('Berhasil','Gagal') DEFAULT 'Berhasil',
  CONSTRAINT fk_struk_transaksi
    FOREIGN KEY (id_transaksi) REFERENCES transaksi(id_transaksi)
    ON UPDATE CASCADE ON DELETE CASCADE
) ENGINE=InnoDB;

-- ==============================
-- 6. Tabel Notifikasi Stok
-- ==============================
CREATE TABLE notifikasi_stok (
  id_notifikasi INT AUTO_INCREMENT PRIMARY KEY,
  id_obat INT NOT NULL,
  pesan VARCHAR(255) NOT NULL,
  tanggal_notifikasi DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  status ENUM('Belum Dibaca','Dibaca') DEFAULT 'Belum Dibaca',
  id_user_penerima INT NULL,
  CONSTRAINT fk_notifikasi_obat
    FOREIGN KEY (id_obat) REFERENCES obat(id_obat)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_notifikasi_user
    FOREIGN KEY (id_user_penerima) REFERENCES users(id_user)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- ==============================
-- 7. Tabel Log Stok
-- ==============================
CREATE TABLE stok_log (
  id_log INT AUTO_INCREMENT PRIMARY KEY,
  id_obat INT NOT NULL,
  tipe ENUM('Masuk','Keluar','Update','Resep','Transaksi') NOT NULL,
  jumlah INT NOT NULL,
  stok_sebelum INT NOT NULL,
  stok_sesudah INT NOT NULL,
  keterangan VARCHAR(255),
  id_user INT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_log_obat
    FOREIGN KEY (id_obat) REFERENCES obat(id_obat)
    ON UPDATE CASCADE ON DELETE CASCADE,
  CONSTRAINT fk_log_user
    FOREIGN KEY (id_user) REFERENCES users(id_user)
    ON UPDATE CASCADE ON DELETE SET NULL
) ENGINE=InnoDB;

-- ==============================
-- 8. Trigger Update Stok Otomatis
-- ==============================
DELIMITER $$

CREATE TRIGGER trg_kurangi_stok_transaksi
AFTER INSERT ON transaksi_detail
FOR EACH ROW
BEGIN
  DECLARE stok_lama INT;
  SELECT stok INTO stok_lama FROM obat WHERE id_obat = NEW.id_obat;

  UPDATE obat
  SET stok = stok - NEW.jumlah_beli
  WHERE id_obat = NEW.id_obat;

  INSERT INTO stok_log (id_obat, tipe, jumlah, stok_sebelum, stok_sesudah, keterangan)
  VALUES (NEW.id_obat, 'Transaksi', NEW.jumlah_beli, stok_lama, stok_lama - NEW.jumlah_beli,
          CONCAT('Pengurangan stok dari transaksi ID ', NEW.id_transaksi));
END$$

CREATE TRIGGER trg_kurangi_stok_resep
AFTER INSERT ON resep_detail
FOR EACH ROW
BEGIN
  DECLARE stok_lama INT;
  SELECT stok INTO stok_lama FROM obat WHERE id_obat = NEW.id_obat;

  UPDATE obat
  SET stok = stok - NEW.jumlah
  WHERE id_obat = NEW.id_obat;

  INSERT INTO stok_log (id_obat, tipe, jumlah, stok_sebelum, stok_sesudah, keterangan)
  VALUES (NEW.id_obat, 'Resep', NEW.jumlah, stok_lama, stok_lama - NEW.jumlah,
          CONCAT('Pengurangan stok dari resep ID ', NEW.id_resep));
END$$

CREATE TRIGGER trg_notifikasi_stok_menipis
AFTER UPDATE ON obat
FOR EACH ROW
BEGIN
  IF NEW.stok <= NEW.batas_minimum THEN
    INSERT INTO notifikasi_stok (id_obat, pesan)
    VALUES (NEW.id_obat, CONCAT('Stok ', NEW.nama_obat, ' menipis. Sisa stok: ', NEW.stok));
  END IF;
END$$

DELIMITER ;

-- ==============================
-- 9. Data Awal / Demo
-- ==============================
INSERT INTO users (nama, username, password, role) VALUES
('Apoteker', 'apoteker', 'apoteker123', 'Apoteker'),
('Kasir', 'kasir', 'kasir123', 'Kasir'),
('Admin', 'admin', 'admin123', 'Admin');

INSERT INTO obat (kode_obat, nama_obat, kategori, satuan, harga, stok, batas_minimum, tanggal_kadaluarsa) VALUES
('OBT001', 'Paracetamol 500 mg', 'Analgesik', 'strip', 7000, 80, 15, '2027-02-10'),
('OBT002', 'Amoxicillin 500 mg', 'Antibiotik', 'strip', 12000, 12, 20, '2026-11-22'),
('OBT003', 'Cetirizine 10 mg', 'Antihistamin', 'strip', 8500, 31, 10, '2027-06-18'),
('OBT004', 'Vitamin C 500 mg', 'Vitamin', 'botol', 15000, 6, 12, '2026-09-15'),
('OBT005', 'Antasida DOEN', 'Pencernaan', 'strip', 9000, 45, 10, '2028-01-09'),
('OBT006', 'Oralit Sachet', 'Elektrolit', 'sachet', 3000, 0, 20, '2027-04-01'),
('OBT007', 'Ibuprofen 400 mg', 'Analgesik', 'strip', 10000, 25, 10, '2027-10-05'),
('OBT008', 'Omeprazole 20 mg', 'Lambung', 'strip', 11000, 18, 8, '2027-08-25');

-- Data transaksi contoh
INSERT INTO transaksi (nomor_transaksi, id_kasir, subtotal, pajak, total, uang_bayar, kembalian, metode_bayar)
VALUES ('TRX-20260610-001', 2, 29000, 0, 29000, 50000, 21000, 'Tunai');

INSERT INTO transaksi_detail (id_transaksi, id_obat, jumlah_beli, harga_satuan, subtotal) VALUES
(1, 1, 2, 7000, 14000),
(1, 4, 1, 15000, 15000);

INSERT INTO struk (id_transaksi, status_cetak) VALUES
(1, 'Berhasil');

-- Data resep contoh
INSERT INTO resep (nomor_resep, nama_pasien, id_apoteker, status, catatan)
VALUES ('RSP-20260610-001', 'Pasien Demo', 1, 'Selesai', 'Contoh resep dari dokter');

INSERT INTO resep_detail (id_resep, id_obat, jumlah, aturan_pakai) VALUES
(1, 3, 1, '1 kali sehari setelah makan'),
(1, 5, 1, '3 kali sehari sebelum makan');

-- Notifikasi awal untuk obat yang memang sudah di bawah batas minimum
INSERT INTO notifikasi_stok (id_obat, pesan)
SELECT id_obat, CONCAT('Stok ', nama_obat, ' menipis. Sisa stok: ', stok)
FROM obat
WHERE stok <= batas_minimum;

-- ==============================
-- 10. View Laporan
-- ==============================
CREATE VIEW view_stok_menipis AS
SELECT
  id_obat,
  kode_obat,
  nama_obat,
  kategori,
  stok,
  batas_minimum,
  CASE
    WHEN stok <= 0 THEN 'Habis'
    WHEN stok <= batas_minimum THEN 'Menipis'
    ELSE 'Aman'
  END AS status_stok
FROM obat
WHERE stok <= batas_minimum;

CREATE VIEW view_laporan_penjualan_harian AS
SELECT
  DATE(tanggal_transaksi) AS tanggal,
  COUNT(id_transaksi) AS jumlah_transaksi,
  SUM(subtotal) AS subtotal_penjualan,
  SUM(pajak) AS total_pajak,
  SUM(total) AS total_penjualan
FROM transaksi
WHERE status = 'Berhasil'
GROUP BY DATE(tanggal_transaksi);

CREATE VIEW view_obat_terjual AS
SELECT
  o.kode_obat,
  o.nama_obat,
  o.kategori,
  SUM(td.jumlah_beli) AS total_terjual,
  SUM(td.subtotal) AS total_pendapatan
FROM transaksi_detail td
JOIN obat o ON td.id_obat = o.id_obat
JOIN transaksi t ON td.id_transaksi = t.id_transaksi
WHERE t.status = 'Berhasil'
GROUP BY o.id_obat, o.kode_obat, o.nama_obat, o.kategori;

-- ==============================
-- 11. Contoh Query Pengujian
-- ==============================
-- SELECT * FROM users;
-- SELECT * FROM obat;
-- SELECT * FROM view_stok_menipis;
-- SELECT * FROM view_laporan_penjualan_harian;
-- SELECT * FROM view_obat_terjual;
