# Struktur Database Sistem Informasi Apotek

## Relasi utama

- Satu `users` dengan role **Apoteker** dapat memproses banyak `resep`.
- Satu `users` dengan role **Kasir** dapat membuat banyak `transaksi`.
- Satu `transaksi` memiliki banyak `transaksi_detail`.
- Satu `resep` memiliki banyak `resep_detail`.
- Satu `obat` dapat muncul pada banyak `transaksi_detail` dan `resep_detail`.
- Satu `obat` dapat memiliki banyak `notifikasi_stok`.
- Perubahan stok dicatat pada `stok_log`.

## Pemetaan ke use case

| Use Case | Tabel yang digunakan |
|---|---|
| Login | `users` |
| Cek Ketersediaan Obat | `obat` |
| Pemberian Obat Resep | `resep`, `resep_detail`, `obat`, `stok_log` |
| Terima Notifikasi Stok Menipis | `notifikasi_stok`, `obat`, `view_stok_menipis` |
| Proses Transaksi Penjualan | `transaksi`, `transaksi_detail`, `obat`, `stok_log` |
| Cetak Struk | `struk`, `transaksi`, `transaksi_detail` |
| Kelola Data Obat | `obat` |
| Monitor Stok Obat | `obat`, `view_stok_menipis` |
| Lihat Laporan Penjualan Otomatis | `transaksi`, `transaksi_detail`, `view_laporan_penjualan_harian`, `view_obat_terjual` |
